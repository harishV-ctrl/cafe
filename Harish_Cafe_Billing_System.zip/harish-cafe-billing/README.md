# Harish Cafe Billing System

A simple responsive cafe billing web app built with HTML, CSS and JavaScript.

## Features
- Menu categories and item search
- Add items and change quantities
- Automatic subtotal, 5% demo GST and total
- Customer name field
- Print bill using the browser print dialog
- Today's completed bill count and sales total
- Sales and next bill number saved in browser localStorage

## Run locally
Open `index.html` in a web browser.

## Publish with GitHub Pages
1. Sign in to GitHub and create a new public repository named `harish-cafe-billing`.
2. Upload `index.html`, `style.css`, `script.js`, and `README.md` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then click **Save**.
6. Wait for GitHub Pages to publish the site. The website address will appear in the Pages section.

## Important notes
- This is a front-end demo. Sales are stored only in the current browser/device; they are not synced between devices.
- The 5% GST is a sample setting. Confirm the correct tax rate and invoice requirements for your business before using it for real billing.
- Do not enter sensitive customer or payment information. No online payment processing is included.
