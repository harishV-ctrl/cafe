const menu = [
 {id:1,name:'Espresso Coffee',category:'Beverages',price:60,icon:'☕'},
 {id:2,name:'Cold Coffee',category:'Beverages',price:100,icon:'🧋'},
 {id:3,name:'Masala Tea',category:'Beverages',price:30,icon:'🍵'},
 {id:4,name:'Veg Sandwich',category:'Snacks',price:80,icon:'🥪'},
 {id:5,name:'French Fries',category:'Snacks',price:90,icon:'🍟'},
 {id:6,name:'Veg Burger',category:'Snacks',price:120,icon:'🍔'},
 {id:7,name:'Chocolate Cake',category:'Desserts',price:110,icon:'🍰'},
 {id:8,name:'Brownie',category:'Desserts',price:90,icon:'🍫'},
 {id:9,name:'Ice Cream',category:'Desserts',price:70,icon:'🍨'}
];
let cart = {};
let activeCategory = 'All';
let billNo = Number(localStorage.getItem('harishBillNo') || 1);
const money = n => '₹' + n.toFixed(2);
function renderCategories(){
 const cats=['All',...new Set(menu.map(x=>x.category))];
 document.getElementById('categories').innerHTML=cats.map(c=>`<button class="category ${activeCategory===c?'active':''}" onclick="setCategory('${c}')">${c}</button>`).join('');
}
function setCategory(c){activeCategory=c;renderCategories();renderMenu()}
function renderMenu(){
 const q=document.getElementById('search').value.toLowerCase();
 const items=menu.filter(x=>(activeCategory==='All'||x.category===activeCategory)&&x.name.toLowerCase().includes(q));
 document.getElementById('menuGrid').innerHTML=items.map(x=>`<button class="menu-item" onclick="addItem(${x.id})"><div class="food-icon">${x.icon}</div><div class="food-name">${x.name}</div><div class="food-category">${x.category}</div><div class="food-bottom"><span class="price">${money(x.price)}</span><span class="add">+ Add</span></div></button>`).join('') || '<p>No menu items found.</p>';
}
function addItem(id){cart[id]=(cart[id]||0)+1;renderCart()}
function changeQty(id,delta){cart[id]=(cart[id]||0)+delta;if(cart[id]<=0)delete cart[id];renderCart()}
function renderCart(){
 const entries=Object.entries(cart);
 document.getElementById('cartItems').innerHTML=entries.length?entries.map(([id,qty])=>{const x=menu.find(m=>m.id===Number(id));return `<div class="cart-row"><div><div class="cart-name">${x.name}</div><div class="cart-price">${money(x.price)} × ${qty} = ${money(x.price*qty)}</div></div><div class="qty"><button onclick="changeQty(${id},-1)">−</button><span>${qty}</span><button onclick="changeQty(${id},1)">+</button></div></div>`}).join(''):'<div class="empty-state">Your order is empty.<br><small>Add items from the menu.</small></div>';
 const subtotal=entries.reduce((s,[id,q])=>s+menu.find(m=>m.id===Number(id)).price*q,0);
 const tax=subtotal*.05;
 document.getElementById('subtotal').textContent=money(subtotal);
 document.getElementById('tax').textContent=money(tax);
 document.getElementById('total').textContent=money(subtotal+tax);
}
function clearOrder(){cart={};document.getElementById('customerName').value='';renderCart()}
function printBill(){
 if(!Object.keys(cart).length){alert('Please add at least one item before printing.');return}
 const subtotal=Object.entries(cart).reduce((s,[id,q])=>s+menu.find(m=>m.id===Number(id)).price*q,0);
 const total=subtotal*1.05;
 const sales=JSON.parse(localStorage.getItem('harishSales')||'[]');
 sales.push({number:billNo,total,when:new Date().toISOString()});
 localStorage.setItem('harishSales',JSON.stringify(sales));
 localStorage.setItem('harishBillNo',String(billNo+1));
 billNo++;
 document.getElementById('billNumber').textContent='#'+String(billNo).padStart(3,'0');
 updateSales();
 window.print();
 clearOrder();
}
function updateSales(){
 const sales=JSON.parse(localStorage.getItem('harishSales')||'[]');
 const today=new Date().toDateString();
 const todays=sales.filter(s=>new Date(s.when).toDateString()===today);
 document.getElementById('salesTotal').textContent=money(todays.reduce((a,b)=>a+b.total,0));
 document.getElementById('billCount').textContent=todays.length;
}
function resetSales(){if(confirm('Clear all demo sales saved in this browser?')){localStorage.removeItem('harishSales');updateSales()}}
document.getElementById('billNumber').textContent='#'+String(billNo).padStart(3,'0');
renderCategories();renderMenu();renderCart();updateSales();
